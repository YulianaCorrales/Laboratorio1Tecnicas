package juegocartas;


public enum Grupo {
    VACIO,
    NON,
    PAR,
    TERNA,
    CUARTA,
    QUINTA,
    SEXTA,
    SEPTIMA,
    OCTAVA,
    NOVENA,
    DECIMA
}

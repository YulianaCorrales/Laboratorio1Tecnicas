
package juegocartas;


public class JuegoCartas {


    public static void main(String[] args) {
        new FrmJuego().setVisible(true);
    }
    
}
